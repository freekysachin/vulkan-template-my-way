#define _CRT_SECURE_NO_WARNINGS
#include<engine.h>

int main() {
	Engine* graphicsEngine = new Engine();
	delete graphicsEngine;
	return 0;
}